
/* Global Variables */
const baseUrl='http://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = '&appid=d4971fb9f06bf5650fabb3dd3cbaee4d&units=imperial';
let zipCode= document.getElementById("zip");
let feelings = document.getElementById("feelings");

const postData = async ( url = '', data = {})=>{
      console.log(data);
      const response = await fetch(url, {
      method: 'POST', 
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
     // Body data type must match "Content-Type" header        
      body: JSON.stringify(data) 
    });

      try {
        const newData = await response.json();
        //console.log(newData);
        return newData;
      }catch(error) {
      console.log("error", error);
      }
  }



// Create a new date instance dynamically with JS
let d = new Date();
//added "+1" to the month because i read that first month start at 0 not 1
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();

document.getElementById('generate').addEventListener('click',action);

function action(e){

    getWeatherInfo(baseUrl,apiKey,zipCode)
  .then(function(data){
      //console.log(data);
    postData('/add',{temp:data['main']['temp'],date:newDate,feel:feelings.value});
  })
  .then(
    retrieveData()
  )
 // .catch(error=>{console.log("error", error);})

}

const getWeatherInfo = async (baseUrl,apiKey,zipCode)=>{
    const res = await fetch(baseUrl+zipCode.value+apiKey)
    try {

        const data = await res.json();
        return data;

      }  catch(error) {
  
        console.log("error", error); 
      }
      

}

const retrieveData = async () =>{
  const request = await fetch('/all');
  try {
  // Transform into JSON
  const allData = await request.json();
  // Write updated data to DOM elements
  document.getElementById('temp').innerHTML = Math.round(allData.temp)+ 'degrees';
  document.getElementById('content').innerHTML = allData.feel;
  document.getElementById("date").innerHTML =allData.date;
  }
  catch(error) {
    console.log("error", error);
    // appropriately handle the error
  }
}


